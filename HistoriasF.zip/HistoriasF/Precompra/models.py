from django.db import models

carnes = {
    "descripción6":['polloganso','polloganso.jpeg'],
    "descripción3":['carneCerdo','carneCerdo.jpg'],
    "descripción1":['lomovetado','lomovetado.jpeg'],
}
cliente = [
    {'nombre':'Pedro','nroOrden':'2','cantidad':'4'}
]
