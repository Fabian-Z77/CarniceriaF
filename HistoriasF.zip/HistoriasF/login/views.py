from django.shortcuts import render

def login(request):
    datos = {
        "correo":"fabian@gmail.com",
        "contraseña":"fabian2003"
    }
    return render(request,'login.html',datos)

