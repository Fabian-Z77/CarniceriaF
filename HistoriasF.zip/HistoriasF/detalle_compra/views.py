from django.shortcuts import render
from detalle_compra import models as data

def detalle_compra(request):
    datos = {
        "carne1":data.carnes1,
        "carne2":data.carnes2,
        "cliente":data.cliente,

    }
    return render(request,'detalle_compra.html',datos)

