from django.db import models

carnes1 = {
    "descripción1":['lomovetado','lomovetado.jpeg'],
    "descripción2":['postapaleta','postapaleta.jpeg'],
    "descripción3":['carneCerdo','carneCerdo.jpg'],
    "descripción4":['carnevacuno','carnevacuno.jpeg'],
    "descripción5":['pollo','pollo.jpg'],
    "descripción6":['polloganso','polloganso.jpeg'],
}
carnes2 = {
    "descripción4":['carnevacuno','carnevacuno.jpeg'],
    "descripción3":['carneCerdo','carneCerdo.jpg'],
    "descripción2":['postapaleta','postapaleta.jpeg'],
    "descripción1":['lomovetado','lomovetado.jpeg'],
    "descripción5":['pollo','pollo.jpg'],
    "descripción6":['polloganso','polloganso.jpeg'],
}
cliente = [
    {'nombre':'Pedro','nroOrden':'2','cantidad':'4'}
]
