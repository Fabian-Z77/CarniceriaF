from django.db import models

carnes1 = {
    "descripción1":['Lomovetado','lomovetado.jpeg',1],
    "descripción2":['PostaPaleta','postapaleta.jpeg',3],
    "descripción3":['CarneCerdo','carneCerdo.jpg',5],
    "descripción4":['CarneVacuno','carnevacuno.jpeg',2],
    "descripción5":['Pollo','pollo.jpg',1],
    "descripción6":['PolloGanso','polloganso.jpeg',2],
}
carnes2 = {
    "descripción4":['CarneVacuno','carnevacuno.jpeg',2],
    "descripción3":['CarneCerdo','carneCerdo.jpg',1],
    "descripción2":['PostaPaleta','postapaleta.jpeg',3],
    "descripción1":['lomovetado','lomovetado.jpeg',4],
    "descripción5":['Pollo','pollo.jpg',1],
    "descripción6":['PolloGanso','polloganso.jpeg',2],
}
cliente = [
    {'nombre':'Pedro','nroOrden1':'2313','nroOrden2':'1512','cantidad':'4'}
]
