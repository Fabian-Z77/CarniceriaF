from django.shortcuts import render
from Precompra import models as data

def Precompra(request):
    dato = {
        "carnes":data.carnes,
        "cliente":data.cliente,
    }
    return render(request,'PreCompra.html',dato)
