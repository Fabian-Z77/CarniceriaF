from django.db import models

carnes = {
    "descripción6":['polloganso','polloganso.jpeg',2],
    "descripción3":['carneCerdo','carneCerdo.jpg',4],
    "descripción1":['lomovetado','lomovetado.jpeg',1],
}
cliente = [
    {'nombre':'Pedro','nroOrden':'2','cantidad':'4'}
]
