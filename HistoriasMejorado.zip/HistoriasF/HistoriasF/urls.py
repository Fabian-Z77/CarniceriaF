from django.contrib import admin
from django.urls import path
import login.views as vista_login
import detalle_compra.views as vista_compra
import Precompra.views as vista_Precompra

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/',vista_login.login,name="login"),
    path('detalle_compra/',vista_compra.detalle_compra,name="detalle_compra"),
    path('Precompra/',vista_Precompra.Precompra,name="Precompra"),
]
